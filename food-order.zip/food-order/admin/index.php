<html>
    <head>
<tittle>food oder website home page</tittle>
<lik rel="stylesheet" href="../css/admin.css">
</head>

<body>
    <!-------Manu dection start---->
    <div class="Manu">
        <div class="wrapper">
             menu goes here
</div>
</div>
    <!-------manu section ends---->
    <!-------Main Content section starts---->

    <div class="mai content">
        <div class="wrapper">
        main content does here
</div>
</div>
<!-----main cotent ends here---->

<!---footer starts here----->
<div class="footer">
<div class="wrapper">
    footer goes here
</div>
</div>
<!-----footer ends here----->


</body>
</html>